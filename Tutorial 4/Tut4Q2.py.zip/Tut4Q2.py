# Membathisi Sikani
# SKNMEM001
# 13/05/2023

import numpy as np
import pandas as pd
import math 
import numpy.random as rd
import matplotlib.pyplot as plt

L = 1    # m
T = 1   # N
N = 500
n = 10  # No of eigenvalues to be returned.
const = (L**2)/(25*T)
b = np.zeros(N)
B = []
D2 = [] 
x = np.linspace(0, L, N+1) [:-1]
dx = x[1] - x[0]
print(dx)

# WE DEFINE/CREATE OUR DESCRITIZATION MATRIX.
for i in range(N):
    B.append(1)
    if i == 0:
        vect = np.zeros(N)
        vect[i] = -2/dx**2
        vect[i+1] = 1/dx**2
    elif i == N-1:
        vect = np.zeros(N)
        vect[i] = -2/dx**2
        vect[i-1] = 1/dx**2
    else:
        vect = np.zeros(N)
        vect[i] = -2/dx**2
        vect[i-1] = 1/dx**2
        vect[i+1] = 1/dx**2
    D2.append(vect)

# WE DEFINE THE DENSITY FUNCTION rho FOR BOTH THE HOMOGENEOUS AND INHOMOGENEOUS.
rho_1 = 1
def rho(x):
    return 1.3 - 0.5*np.sin(np.pi*x/L)

# WE COMPUTE THE MASS DENSITY MATRIX.
rho_M = np.diag(rho(x))

# WE SEARCH FOR THE EIGENVALUES AND EIGENFUNCTIONS.
A = D2 + np.diag((T/np.diag(rho_M)) * np.ones(N))
eigenvalues, eigenvectors = np.linalg.eig(A)
sorted_indices = np.argsort(eigenvalues)[:n]
omega = np.sqrt(-eigenvalues[sorted_indices])
X = eigenvectors[:, sorted_indices]
print("BELOW IS THE FIRST 10 EIGENVALUES $\omega$ OF THE DIFFERENTIAL EQUATION.")
print(omega)

n_v = [1, 5, 9]
n_va = [1, 5, 9]

colour = ['k', 'b', 'r']
for i, j, col in zip(n_v, n_v, colour):
    waveform = X[:, i-1]
    plt.figure(j)
    plt.plot(x, waveform, color = col)
    plt.xlabel('$x$')
    plt.ylabel(f'$X_{j}(x)$')
    plt.title(f'Waveform for eigenvalue {j}')
plt.show()
